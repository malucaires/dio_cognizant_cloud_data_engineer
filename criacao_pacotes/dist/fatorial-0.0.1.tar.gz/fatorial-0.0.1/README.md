# fatorial

    Calcula o fatorial de um número
    :param num: número a ser calculado
    :param show: (opcional) mostra memória de cálculo
    :return: valor faotiral de um número

## Installation

Use the package manager [pip](https://pip.pypa.io/en/stable/) to install package_name

```bash
pip install package_name
```

## Usage

```python
from package_name import file1_name
file1_name.my_function()
```

## Author
malucaires

## License
[MIT](https://choosealicense.com/licenses/mit/)