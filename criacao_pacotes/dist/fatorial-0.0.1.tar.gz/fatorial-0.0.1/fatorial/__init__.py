# Programa Principal
numero = int(input('Digite um valor: '))
print(fatorial(numero, True))